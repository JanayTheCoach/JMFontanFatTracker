import React, { useState, useMemo } from "react";

type Entry = {
  id: number;
  foodItem: string;
  fatPerServing: string;
  servings: string;
};

type DayLog = {
  id: number;
  date: string;
  total: number;
};

const App: React.FC = () => {
  const [entries, setEntries] = useState<Entry[]>([
    { id: 1, foodItem: "", fatPerServing: "", servings: "" },
  ]);

  const [history, setHistory] = useState<DayLog[]>([]);
  const [dateLabel, setDateLabel] = useState<string>("");

  const dailyTotal = useMemo(() => {
    return entries.reduce((sum, entry) => {
      const fat = parseFloat(entry.fatPerServing);
      const serv = parseFloat(entry.servings);
      if (isNaN(fat) || isNaN(serv)) return sum;
      return sum + fat * serv;
    }, 0);
  }, [entries]);

  const handleEntryChange = (
    id: number,
    field: "foodItem" | "fatPerServing" | "servings",
    value: string
  ) => {
    setEntries((prev) =>
      prev.map((entry) =>
        entry.id === id ? { ...entry, [field]: value } : entry
      )
    );
  };

  const addRow = () => {
    setEntries((prev) => [
      ...prev,
      {
        id: Date.now(),
        foodItem: "",
        fatPerServing: "",
        servings: "",
      },
    ]);
  };

  const removeRow = (id: number) => {
    setEntries((prev) => prev.filter((e) => e.id !== id));
  };

  const resetDay = () => {
    setEntries([{ id: 1, foodItem: "", fatPerServing: "", servings: "" }]);
  };

  const logDay = () => {
    const hasData = entries.some(
      (e) =>
        e.foodItem.trim() !== "" ||
        e.fatPerServing.trim() !== "" ||
        e.servings.trim() !== ""
    );

    if (!hasData) {
      alert("No entries to log yet.");
      return;
    }

    setHistory((prev) => [
      ...prev,
      {
        id: Date.now(),
        date: dateLabel || "No date entered",
        total: dailyTotal,
      },
    ]);

    resetDay();
    setDateLabel("");
  };

  const deleteOneLog = (id: number) => {
    setHistory((prev) => prev.filter((day) => day.id !== id));
  };

  const clearHistory = () => {
    if (window.confirm("Clear ALL logged history?")) {
      setHistory([]);
    }
  };

  return (
    <div
      style={{
        maxWidth: 900,
        margin: "0 auto",
        padding: 20,
        fontFamily: "sans-serif",
      }}
    >
      <h1>Fontan Fat Tracker</h1>

      <div style={{ marginBottom: 12 }}>
        <label>
          <strong>Date & time: </strong>
          <input
            type="text"
            value={dateLabel}
            onChange={(e) => setDateLabel(e.target.value)}
            style={{ padding: 4, minWidth: 200 }}
            placeholder="Date and time of day"
          />
        </label>
      </div>

      <table
        style={{
          width: "100%",
          borderCollapse: "collapse",
          marginBottom: 16,
        }}
      >
        <thead>
          <tr>
            <th
              style={{
                borderBottom: "1px solid #ccc",
                textAlign: "left",
                padding: 6,
              }}
            >
              Food item
            </th>
            <th
              style={{
                borderBottom: "1px solid #ccc",
                textAlign: "left",
                padding: 6,
              }}
            >
              Fat per serving (g)
            </th>
            <th
              style={{
                borderBottom: "1px solid #ccc",
                textAlign: "left",
                padding: 6,
              }}
            >
              Servings
            </th>
            <th
              style={{
                borderBottom: "1px solid #ccc",
                textAlign: "left",
                padding: 6,
              }}
            >
              Servings total (g)
            </th>
            <th
              style={{
                borderBottom: "1px solid #ccc",
                textAlign: "left",
                padding: 6,
              }}
            >
              Actions
            </th>
          </tr>
        </thead>

        <tbody>
          {entries.map((entry) => {
            const fat = parseFloat(entry.fatPerServing);
            const serv = parseFloat(entry.servings);
            const rowTotal = !isNaN(fat) && !isNaN(serv) ? fat * serv : 0;

            return (
              <tr key={entry.id}>
                <td style={{ padding: 6 }}>
                  <input
                    type="text"
                    value={entry.foodItem}
                    onChange={(e) =>
                      handleEntryChange(entry.id, "foodItem", e.target.value)
                    }
                    style={{ width: "100%", padding: 4 }}
                    placeholder="Pretzels, bean dip…"
                  />
                </td>
                <td style={{ padding: 6 }}>
                  <input
                    type="number"
                    min={0}
                    step={0.01}
                    value={entry.fatPerServing}
                    onChange={(e) =>
                      handleEntryChange(
                        entry.id,
                        "fatPerServing",
                        e.target.value
                      )
                    }
                    style={{ width: "100%", padding: 4 }}
                    placeholder="g"
                  />
                </td>
                <td style={{ padding: 6 }}>
                  <input
                    type="number"
                    min={0}
                    step={0.01}
                    value={entry.servings}
                    onChange={(e) =>
                      handleEntryChange(entry.id, "servings", e.target.value)
                    }
                    style={{ width: "100%", padding: 4 }}
                    placeholder="servings"
                  />
                </td>
                <td style={{ padding: 6 }}>
                  {rowTotal > 0 ? rowTotal.toFixed(2) : ""}
                </td>
                <td style={{ padding: 6 }}>
                  {entries.length > 1 && (
                    <button onClick={() => removeRow(entry.id)}>Remove</button>
                  )}
                </td>
              </tr>
            );
          })}
        </tbody>
      </table>

      <button onClick={addRow} style={{ marginBottom: 12 }}>
        + Add food row
      </button>

      <div style={{ marginTop: 12, marginBottom: 16 }}>
        <strong>Daily total: </strong>
        {dailyTotal.toFixed(2)} g fat
      </div>

      <div style={{ marginBottom: 24 }}>
        <button onClick={logDay} style={{ marginRight: 8 }}>
          Log day and reset
        </button>
        <button onClick={resetDay}>Reset current day</button>
      </div>

      <h2>Logged daily totals</h2>

      {history.length === 0 && <p>No days logged yet.</p>}

      {history.length > 0 && (
        <>
          <button onClick={clearHistory} style={{ marginBottom: 8 }}>
            Clear ALL history
          </button>
          <ul>
            {history.map((day) => (
              <li key={day.id}>
                <strong>{day.date}</strong>: {day.total.toFixed(2)} g fat{" "}
                <button
                  style={{ marginLeft: 10 }}
                  onClick={() => deleteOneLog(day.id)}
                >
                  Delete
                </button>
              </li>
            ))}
          </ul>
        </>
      )}

      <p style={{ marginTop: 50, fontSize: "0.75rem", opacity: 0.7 }}>
        made with love by another heart momma Janay Webster 🫀 Inspired by Jonny
        Tsunami
      </p>
    </div>
  );
};

export default App;
